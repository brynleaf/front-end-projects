# Expense Tracker

## Description
It is an online Expense Tracker which is used to keep record of expenses .

## Stacks Used
* HTML  
* CSS
* JavaScript

## Demo

![Images](https://github.com/rittikadeb/Ace-The-FrontEnd-1/blob/main/Expense%20Tracker/Images/demo_2.PNG)


![demo](https://user-images.githubusercontent.com/76259897/157314522-662c766c-9172-4254-9394-2fad1ad48fe9.gif)
