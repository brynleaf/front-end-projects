# Instagram HomePage Clone:
> It's Instagram UI Clone made using HTML,CSS and it's responsive in nature.
## Tech Stack : THML5,CSS3

## Demo:


https://user-images.githubusercontent.com/77873383/164985543-a27363d5-a625-4afc-bde4-a68867c3fc83.mp4

