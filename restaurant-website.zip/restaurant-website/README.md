## Synopsis

This is a restaurant website.

It was created using:

* HTML
* CSS
* JavaScript

## Live Demo

To see the live demo, please [click here](https://patriciageo3.github.io/restaurant-website/).

## Authors

Coded by Patricia Georgescu

Design by George Olaru

## License & Copyrights
Design from Dribble.

Author: George Olaru. To see the template design, please [click here](https://dribbble.com/shots/1560982-Rosa-Restaurant-Website/attachments/239212).

## Quick Live Preview
![Alt text](assets/img/preview.JPG "Preview")