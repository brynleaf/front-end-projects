![](https://img.shields.io/badge/Page-Quote_Generator-yellow.svg)
![](https://img.shields.io/badge/Tools-HTML,_CSS_and_JavaScript-skyblue.svg)
![](https://img.shields.io/badge/Level-Basic-red.svg)
![](https://img.shields.io/badge/Status-Complete-green.svg) 

<h1 align="center">Quote Generator</h1>

<h2> Tech Stack </h2>
<ol>
  <li> HTML <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="20" height="20"/> </li>
  <li> CSS <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="20" height="20"/> </li>
  <li> JavaScript <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="20" height="20"/> </li>
</ol>

<hr>

<p align="center">
<img src="https://i.postimg.cc/tCq1DbDj/Screenshot.png" /> 
</p>


### [<p align="center">🔗 Page Link </p>](https://somyaranjansahu.github.io/Quote-Generator/)

<h3 align="center"> Show ❤️ by Starring this Repo </h3>